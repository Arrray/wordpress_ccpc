<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after
 *
 * @package WordPress
 * @subpackage Twenty_Sixteen
 * @since Twenty Sixteen 1.0
 */
?>

<div class="footer mainWidth" style="height: 50px;position: fixed;bottom:0;left: 0">
	<div class="footerContent" style="height: 50px">
<!--		<div class="footer_left left">-->
<!--			<span>&copy;2016 东北大学秦皇岛分校安全工作处 ALLRIGHT RESERVRED</span><br />-->
<!--			<span>学校地址：河北省秦皇岛市经济技术开发区泰山路143号</span>-->
<!--		</div>-->
<!--		<div class="footer_center left">-->
<!--			<span>邮编:066004</span><br />-->
<!--			<span>报警电话:8052404</span>-->
<!--		</div>-->
<!--		<div class="footer_right left">-->
<!--			<span><a href="http://www.neu.edu.cn">东北大学</a></span><br />-->
<!--			<span><a href="http://www.neuq.edu.cn">东北大学秦皇岛分校</a></span>-->
<!--		</div>-->
		<div style="height: 50px">
			&copy;2016 中国大学生程序设计竞赛 版权所有
		</div>
	</div>
</div>
</div>
</body>
<?php wp_footer();?>
</html>
